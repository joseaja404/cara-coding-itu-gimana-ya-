<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'hacker') {
    header("Location: login.php");
    exit;
}

$generated_report = null;
$bug_type   = $_POST['bug_type'] ?? '';
$target_url = $_POST['target_url'] ?? '';
$notes      = $_POST['notes'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['download_txt'])) {
        $content = $_POST['report_content'];
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="bug_report_draft.txt"');
        echo $content;
        exit;
    }

    $host = parse_url($target_url, PHP_URL_HOST) ?: 'target-system.com';
    $bug_lower = strtolower($bug_type);

    $severity = "High";
    if (strpos($bug_lower, 'xss') !== false || strpos($bug_lower, 'csrf') !== false) {
        $severity = "Medium";
    } elseif (strpos($bug_lower, 'rce') !== false || strpos($bug_lower, 'sqli') !== false) {
        $severity = "Critical";
    }

    $raw_report = "=== HACKERCROWD PROJECT - AI BUG REPORT ===\n\n" .
                  "Judul Laporan: [" . strtoupper($bug_type) . "] Vulnerability on $host\n" .
                  "Target Endpoint: $target_url\n" .
                  "Severity Level: $severity\n\n" .
                  "--- DESKRIPSI CELAH ---\n" .
                  "Ditemukan kelemahan keamanan berupa $bug_type pada endpoint $target_url. " . ($notes ?: 'Pengujian menunjukkan ketidakcukupan validasi input.') . "\n\n" .
                  "--- LANGKAH REPRODUKSI (PoC) ---\n" .
                  "1. Akses URL target: $target_url\n" .
                  "2. Masukkan payload pengujian pada parameter rentan.\n" .
                  "3. Amati anomali respon atau eksekusi perintah.\n\n" .
                  "--- DAMPAK KEAMANAN (IMPACT) ---\n" .
                  "Penyerang dapat mengeksploitasi kerentanan ini untuk mengakses data sensitif atau melakukan tindakan tidak terotorisasi.\n";

    $generated_report = [
        'title'    => "[" . strtoupper($bug_type) . "] Vulnerability found on " . $host,
        'severity' => $severity,
        'summary'  => "Ditemukan celah $bug_type pada $target_url. " . ($notes ?: 'Validasi input tidak memadai.'),
        'raw'      => $raw_report
    ];

    log_activity($conn, $_SESSION['user_id'], "AI_REPORT_GEN", "Hacker menggunakan AI Bug Report Assistant untuk: $bug_type");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Bug Report Assistant - HackerCrowd Project</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-slate-900 px-4 py-3 border-bottom border-secondary">
    <a class="navbar-brand fw-bold" href="index.php">
        <i class="bi bi-shield-lock-fill text-success fs-3 me-2"></i> Hacker<span class="text-success">Crowd</span> Project
    </a>
    <div class="ms-auto d-flex align-items-center">
        <a href="ai_payload.php" class="btn btn-outline-warning btn-sm me-2 rounded-pill px-3"><i class="bi bi-code-slash"></i> AI Payload Generator</a>
        <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2 rounded-pill px-3"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-3"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
</nav>

<div class="container my-5" style="max-width: 800px;">
    <div class="text-center mb-5">
        <div class="bg-success bg-opacity-10 text-success rounded-circle d-inline-flex p-3 mb-3 border border-success border-opacity-25 shadow">
            <i class="bi bi-file-earmark-text-fill display-5"></i>
        </div>
        <h2 class="fw-bold text-white">AI Bug Report Assistant 📝</h2>
        <p class="text-secondary opacity-75">Susun draf laporan kerentanan secara profesional, terstruktur, dan siap dikirimkan kepada perusahaan.</p>
    </div>

    <div class="ai-card p-4 shadow-lg mb-5">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-light small fw-bold">Jenis Kerentanan</label>
                <input type="text" name="bug_type" class="form-control bg-dark text-white border-secondary" placeholder="Contoh: Stored XSS, SQLi, IDOR" value="<?= htmlspecialchars($bug_type) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-light small fw-bold">URL Target / Endpoint</label>
                <input type="url" name="target_url" class="form-control bg-dark text-white border-secondary" placeholder="https://target-website.com/endpoint" value="<?= htmlspecialchars($target_url) ?>" required>
            </div>
            <div class="mb-4">
                <label class="form-label text-light small fw-bold">Catatan Temuan Kasar</label>
                <textarea name="notes" class="form-control bg-dark text-white border-secondary" rows="3" placeholder="Tuliskan catatan penemuan Anda..."><?= htmlspecialchars($notes) ?></textarea>
            </div>
            <button type="submit" class="btn btn-success w-100 py-2 fw-bold rounded-3 shadow">
                <i class="bi bi-magic me-1"></i> Generate Draf Laporan Bug
            </button>
        </form>
    </div>

    <?php if ($generated_report): ?>
    <div class="ai-card p-4 shadow-lg border-success border-2">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold text-success mb-0"><i class="bi bi-file-earmark-check me-2"></i>Draf Laporan Profesional</h4>
            <span class="badge bg-danger px-3 py-2"><?= $generated_report['severity'] ?> Severity</span>
        </div>
        <hr class="border-secondary mb-3">

        <div class="mb-3">
            <label class="small text-secondary fw-bold">Judul Disarankan:</label>
            <div class="p-2 bg-dark rounded border border-secondary font-monospace text-white"><?= htmlspecialchars($generated_report['title']) ?></div>
        </div>

        <div class="mb-4">
            <label class="small text-secondary fw-bold">Ringkasan:</label>
            <div class="p-2 bg-dark rounded border border-secondary text-light"><?= htmlspecialchars($generated_report['summary']) ?></div>
        </div>

        <form method="POST">
            <input type="hidden" name="report_content" value="<?= htmlspecialchars($generated_report['raw']) ?>">
            <button type="submit" name="download_txt" class="btn btn-outline-success w-100 fw-bold py-2 rounded-3">
                <i class="bi bi-download me-1"></i> Unduh Draf Laporan (.TXT)
            </button>
        </form>
    </div>
    <?php endif; ?>
</div>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/native.js"></script>
</body>
</html>