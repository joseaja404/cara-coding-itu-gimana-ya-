<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || ($_SESSION['role'] != 'owner' && $_SESSION['role'] != 'company')) {
    header("Location: login.php");
    exit;
}

$mitigation_result = "";
$report_title = "";
$severity = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $report_title = trim($_POST['report_title']);
    $vulnerability_type = trim($_POST['vulnerability_type']);
    $vulnerable_code = trim($_POST['vulnerable_code']);

    
    $mitigation_result = "### 🛡️ Analisis & Rekomendasi Mitigasi AI Copilot\n\n";
    $mitigation_result .= "**Target Kerentanan:** " . htmlspecialchars($report_title) . " (" . htmlspecialchars($vulnerability_type) . ")\n\n";
    
    $mitigation_result .= "#### 1. Analisis Akar Masalah (Root Cause):\n";
    if (stripos($vulnerability_type, 'SQL') !== false) {
        $mitigation_result .= "Aplikasi Anda rentan terhadap *SQL Injection* karena parameter input pengguna digabungkan secara langsung ke dalam kueri SQL tanpa melalui proses *prepared statements* atau *escaping* yang aman.\n\n";
        $mitigation_result .= "#### 2. Contoh Kode Perbaikan (Secure Code Patch):\n";
        $mitigation_result .= "```php\n// Gunakan Prepared Statements dengan MySQLi\n$stmt = \$conn->prepare(\"SELECT * FROM users WHERE email = ?\");\n\$stmt->bind_param(\"s\", \$email);\n\$stmt->execute();\n\$result = \$stmt->get_result();\n```\n\n";
    } elseif (stripos($vulnerability_type, 'XSS') !== false) {
        $mitigation_result .= "Aplikasi Anda rentan terhadap *Cross-Site Scripting (XSS)* karena data input yang diberikan oleh pengguna dirender langsung ke dalam halaman HTML tanpa melalui proses sanitasi.\n\n";
        $mitigation_result .= "#### 2. Contoh Kode Perbaikan (Secure Code Patch):\n";
        $mitigation_result .= "```php\n// Gunakan htmlspecialchars() saat menampilkan input\necho htmlspecialchars(\$user_input, ENT_QUOTES, 'UTF-8');\n```\n\n";
    } else {
        $mitigation_result .= "Kerentanan ini memungkinkan penyerang mengeksploitasi celah logika atau kontrol akses pada fungsi terkait. Pastikan untuk memvalidasi setiap hak akses sesi pengguna (*authorization checks*) sebelum memproses data sensitif.\n\n";
        $mitigation_result .= "#### 2. Contoh Kode Perbaikan (Secure Code Patch):\n";
        $mitigation_result .= "```php\n// Validasi peran pengguna secara ketat\nif (!isset(\$_SESSION['role']) || (\$_SESSION['role'] != 'owner' && \$_SESSION['role'] != 'company')) {\n    die('Access Denied');\n}\n```\n\n";
    }

    $mitigation_result .= "#### 3. Langkah Pengujian Lanjutan (Validation Steps):\n";
    $mitigation_result .= "* Terapkan patch di atas pada lingkungan *staging* / pengujian.\n";
    $mitigation_result .= "* Lakukan pengujian ulang menggunakan *payload* serupa untuk memastikan celah telah tertutup.\n";
    $mitigation_result .= "* Perbarui status laporan di platform HackerCrowd menjadi 'Resolved'.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Mitigation - HackerCrowd</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark border-bottom border-secondary border-opacity-25 px-4 py-3">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="<?= ($_SESSION['role'] == 'owner') ? 'owner_dashboard.php' : 'company_dashboard.php'; ?>">
            <i class="bi bi-shield-lock-fill text-success me-2"></i> Hacker<span class="text-success">Crowd</span> 
            <span class="badge bg-warning text-dark ms-2">AI Mitigation HackerCrowd</span>
        </a>
        <a href="<?= ($_SESSION['role'] == 'owner') ? 'owner_dashboard.php' : 'company_dashboard.php'; ?>" class="btn btn-outline-light btn-sm rounded-pill px-3"><i class="bi bi-arrow-left me-1"></i> Kembali ke Dashboard</a>
    </div>
</nav>

<div class="container my-5" style="max-width: 900px;">
    <div class="mb-4">
        <h2 class="fw-bold text-white mb-1"><i class="bi bi-cpu text-success me-2"></i>AI Vulnerability Mitigation</h2>
        <p class="text-secondary small">Bantu tim pengembang Anda menghasilkan solusi perbaikan kode secara otomatis berdasarkan laporan celah keamanan yang masuk.</p>
    </div>

    <div class="row g-4">
        
        <div class="col-lg-5">
            <div class="card card-custom p-4 h-100">
                <h5 class="fw-bold text-white mb-3">Detail Temuan Bug</h5>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label small text-secondary">Judul Laporan / Temuan</label>
                        <input type="text" name="report_title" class="form-control bg-dark text-white border-secondary" placeholder="Contoh: SQL Injection di Halaman Login" value="<?= htmlspecialchars($report_title ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-secondary">Jenis Kerentanan (Vulnerability Type)</label>
                        <select name="vulnerability_type" class="form-select bg-dark text-white border-secondary">
                            <option value="SQL Injection">SQL Injection (SQLi)</option>
                            <option value="Cross-Site Scripting">Cross-Site Scripting (XSS)</option>
                            <option value="Broken Access Control">Broken Access Control</option>
                            <option value="Remote Code Execution">Remote Code Execution (RCE)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-secondary">Cuplikan Kode Rentan (Opsional)</label>
                        <textarea name="vulnerable_code" class="form-control bg-dark text-white border-secondary font-monospace small" rows="4" placeholder="Tempelkan kode yang bermasalah di sini..."><?= htmlspecialchars($vulnerable_code ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-h1-green w-100 py-2"><i class="bi bi-magic me-1"></i> Generate Patch & Solusi AI</button>
                </form>
            </div>
        </div>

        
        <div class="col-lg-7">
            <div class="card card-custom p-4 h-100">
                <h5 class="fw-bold text-white mb-3">Rekomendasi Perbaikan AI</h5>
                <?php if (!empty($mitigation_result)): ?>
                    <div class="text-secondary small" style="line-height: 1.7;">
                        <?php 
                            echo nl2br(htmlspecialchars($mitigation_result)); 
                        ?>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted my-auto py-5">
                        <i class="bi bi-robot display-4 d-block mb-2 text-secondary opacity-50"></i>
                        <p class="small">Masukkan detail laporan di samping lalu klik tombol <strong>Generate Patch</strong> untuk melihat hasil analisis mitigasi dari AI.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/native.js"></script>
</body>
</html>