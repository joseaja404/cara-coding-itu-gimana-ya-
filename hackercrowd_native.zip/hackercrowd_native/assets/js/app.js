

(function () {
  "use strict";

  var prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var finePointer = window.matchMedia("(pointer: fine)").matches;

  
  var lenis = null;
  if (!prefersReduced && typeof window.Lenis === "function") {
    lenis = new window.Lenis({ duration: 1.15, smoothWheel: true });
    function raf(t) { lenis.raf(t); requestAnimationFrame(raf); }
    requestAnimationFrame(raf);
  }

  
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener("click", function (e) {
      var id = a.getAttribute("href");
      if (id.length < 2) return;
      var el = document.querySelector(id);
      if (!el) return;
      e.preventDefault();
      if (lenis) { lenis.scrollTo(el, { offset: -70 }); }
      else { el.scrollIntoView({ behavior: "smooth" }); }
    });
  });

  
  document.body.classList.add("is-loaded");

  
  var nav = document.querySelector(".navbar-custom");
  function onScrollNav() {
    if (!nav) return;
    nav.classList.toggle("is-scrolled", window.scrollY > 24);
  }
  window.addEventListener("scroll", onScrollNav, { passive: true });
  onScrollNav();

  
  var autoSelectors = [
    ".card-stat", ".card-auth", ".report-card", ".ai-card",
    ".leaderboard-card", ".bento-item", ".step-card", ".stat-cell",
    ".section-head", ".cta-panel"
  ];
  var revealEls = [];
  autoSelectors.forEach(function (sel) {
    document.querySelectorAll(sel).forEach(function (el) {
      if (!el.classList.contains("rv")) {
        el.classList.add("rv");
        revealEls.push(el);
      }
    });
  });
  document.querySelectorAll("[data-reveal]").forEach(function (el) { revealEls.push(el); });

  
  var groups = new Map();
  revealEls.forEach(function (el) {
    var p = el.parentElement;
    if (!groups.has(p)) groups.set(p, 0);
    var i = groups.get(p);
    el.style.setProperty("--rv-delay", Math.min(i * 0.08, 0.5) + "s");
    groups.set(p, i + 1);
  });

  if ("IntersectionObserver" in window && !prefersReduced) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("is-inview");
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("is-inview"); });
  }

  
  function animateCount(el) {
    var target = parseFloat(el.getAttribute("data-count")) || 0;
    var decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
    var prefix = el.getAttribute("data-prefix") || "";
    var suffix = el.getAttribute("data-suffix") || "";
    var start = null;
    var dur = 1600;
    function frame(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var eased = 1 - Math.pow(1 - p, 4);
      var val = target * eased;
      el.textContent = prefix + val.toLocaleString("en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      }) + suffix;
      if (p < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }
  var counters = document.querySelectorAll("[data-count]");
  if (counters.length && "IntersectionObserver" in window && !prefersReduced) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { animateCount(en.target); cio.unobserve(en.target); }
      });
    }, { threshold: 0.4 });
    counters.forEach(function (el) { cio.observe(el); });
  } else {
    counters.forEach(function (el) {
      var d = parseInt(el.getAttribute("data-decimals") || "0", 10);
      el.textContent = (el.getAttribute("data-prefix") || "") +
        (parseFloat(el.getAttribute("data-count")) || 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }) +
        (el.getAttribute("data-suffix") || "");
    });
  }

  
  var pxEls = Array.prototype.slice.call(document.querySelectorAll("[data-parallax]"));
  function parallax() {
    var mid = window.innerHeight / 2;
    pxEls.forEach(function (el) {
      var speed = parseFloat(el.getAttribute("data-parallax")) || 0.1;
      var r = el.getBoundingClientRect();
      var off = (r.top + r.height / 2 - mid) * speed;
      el.style.transform = "translate3d(0," + off.toFixed(1) + "px,0)";
    });
  }
  if (pxEls.length && !prefersReduced) {
    if (lenis) { lenis.on("scroll", parallax); }
    window.addEventListener("scroll", parallax, { passive: true });
    parallax();
  }

  
  var hero = document.querySelector(".hero-section");
  if (hero && finePointer && !prefersReduced) {
    var layers = hero.querySelectorAll(".aurora-orb, .terminal-window, .floating-code");
    hero.addEventListener("mousemove", function (e) {
      var cx = (e.clientX / window.innerWidth - 0.5);
      var cy = (e.clientY / window.innerHeight - 0.5);
      layers.forEach(function (el, i) {
        var depth = (i % 3 + 1) * 9;
        el.style.translate = (cx * depth).toFixed(1) + "px " + (cy * depth).toFixed(1) + "px";
      });
    });
  }

  
  if (finePointer && !prefersReduced) {
    document.querySelectorAll(".btn-glow-green, .btn-h1-green").forEach(function (btn) {
      btn.addEventListener("mousemove", function (e) {
        var r = btn.getBoundingClientRect();
        var x = (e.clientX - r.left - r.width / 2) * 0.18;
        var y = (e.clientY - r.top - r.height / 2) * 0.3;
        btn.style.transform = "translate(" + x.toFixed(1) + "px," + y.toFixed(1) + "px)";
      });
      btn.addEventListener("mouseleave", function () { btn.style.transform = ""; });
    });
  }
})();
