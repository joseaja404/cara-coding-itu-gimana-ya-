<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


$host     = getenv('DB_HOST') ?: "sql105.infinityfree.com";
$user     = getenv('DB_USER') ?: "if0_43145767";
$password = (getenv('DB_PASS') !== false) ? getenv('DB_PASS') : "Garuda195";
$dbname   = getenv('DB_NAME') ?: "if0_43145767_hackercrowd";


$conn = new mysqli($host, $user, $password, $dbname);


if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}


$conn->set_charset("utf8mb4");















function ensure_schema($conn) {
    
    $conn->query("CREATE TABLE IF NOT EXISTS programs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        scope TEXT,
        reward VARCHAR(100) DEFAULT '',
        status VARCHAR(50) DEFAULT 'Live',
        verification_status VARCHAR(50) DEFAULT 'Active/Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    
    $conn->query("CREATE TABLE IF NOT EXISTS reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        hacker_id INT NOT NULL,
        program_id INT DEFAULT NULL,
        title VARCHAR(255) NOT NULL,
        vulnerability_type VARCHAR(100) DEFAULT 'Lainnya / Umum',
        severity VARCHAR(20) DEFAULT 'Medium',
        vulnerability_details TEXT,
        attachment VARCHAR(255) DEFAULT NULL,
        status VARCHAR(50) DEFAULT 'New',
        payment_status VARCHAR(20) DEFAULT 'Unpaid',
        reward DECIMAL(10,2) DEFAULT 0.00,
        verification_status VARCHAR(50) DEFAULT 'Active/Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    
    $conn->query("CREATE TABLE IF NOT EXISTS report_comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_id INT NOT NULL,
        user_id INT NOT NULL,
        comment TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    
    $conn->query("CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    
    $conn->query("CREATE TABLE IF NOT EXISTS activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT DEFAULT NULL,
        action VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    
    
    @$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_pic VARCHAR(255) DEFAULT NULL");
    @$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS fullname VARCHAR(255) DEFAULT ''");
    @$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS ptkp_status VARCHAR(20) DEFAULT 'TK/0'");
}
ensure_schema($conn);









function log_activity($conn, $user_id, $action, $description) {
    
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)");
    if ($stmt) {
        
        $uid = ($user_id !== null && is_numeric($user_id)) ? intval($user_id) : NULL;
        $stmt->bind_param("iss", $uid, $action, $description);
        $stmt->execute();
        $stmt->close();
    }
}
?>