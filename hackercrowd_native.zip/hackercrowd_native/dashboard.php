<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);

if (file_exists('config.php')) {
    require_once 'config.php';
} else {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}


if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}

$user_id = intval($_SESSION['user_id']);
$username = $_SESSION['username'] ?? 'Researcher';


$total_reports = 0;
$resolved_reports = 0;
$total_earnings_usd = 0;

if (isset($conn)) {
    $r_cols = [];
    $res_rc = @$conn->query("SHOW COLUMNS FROM reports");
    if ($res_rc) { while ($rc = $res_rc->fetch_assoc()) { $r_cols[] = $rc['Field']; } }
    
    $id_col = in_array('hacker_id', $r_cols) ? 'hacker_id' : (in_array('user_id', $r_cols) ? 'user_id' : null);
    $reward_col = in_array('reward', $r_cols) ? 'reward' : (in_array('bounty', $r_cols) ? 'bounty' : null);

    if ($id_col) {
        $stmt_stats = $conn->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved FROM reports WHERE {$id_col} = ?");
        if ($stmt_stats) {
            $stmt_stats->bind_param("i", $user_id);
            $stmt_stats->execute();
            $res_stats = $stmt_stats->get_result()->fetch_assoc();
            $total_reports = intval($res_stats['total'] ?? 0);
            $resolved_reports = intval($res_stats['resolved'] ?? 0);
            $stmt_stats->close();
        }

        $sel_col = $reward_col ? "status, {$reward_col} as reward_val" : "status, '350.00' as reward_val";
        $stmt_payout = $conn->prepare("SELECT {$sel_col} FROM reports WHERE {$id_col} = ?");
        if ($stmt_payout) {
            $stmt_payout->bind_param("i", $user_id);
            $stmt_payout->execute();
            $res_payout = $stmt_payout->get_result();
            while ($row = $res_payout->fetch_assoc()) {
                $status = $row['status'] ?? 'Pending';
                $raw = $row['reward_val'] ?? ($status === 'Resolved' ? '350.00' : '0.00');
                preg_match('/[0-9\.]+/', str_replace([',', '$'], '', $raw), $matches);
                $amt = isset($matches[0]) ? floatval($matches[0]) : ($status === 'Resolved' ? 350.00 : 0.00);
                if ($status === 'Resolved' || $amt > 0) {
                    $total_earnings_usd += $amt;
                }
            }
            $stmt_payout->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hacker Portal - HackerCrowd</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark navbar-custom px-4 py-3 sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="dashboard.php">
            <i class="bi bi-shield-shaded text-success fs-3 me-2"></i>
            <span class="fs-4">Hacker<span class="text-success">Crowd</span></span>
            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 ms-3 px-3 py-1 fs-6 rounded-pill">Hacker Portal</span>
        </a>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <a href="leaderboard.php" class="btn btn-sm btn-outline-success fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-trophy me-1"></i> Leaderboard</a>
            <a href="messages.php" class="btn btn-sm btn-outline-success fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-chat-dots me-1"></i> Live Chat</a>
            <a href="tax_report.php" class="btn btn-sm btn-outline-success fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-receipt me-1"></i> Tax & Payout Slip</a>
            <a href="ai_assistant.php" class="btn btn-sm btn-outline-success fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-cpu me-1"></i> AI Hacker Copilot</a>
            <a href="logout.php" class="btn btn-sm btn-outline-light fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-box-arrow-right me-1"></i> Keluar</a>
        </div>
    </div>
</nav>


<div class="container my-5" style="max-width: 1200px;">
    
    
    <div class="card card-stat p-4 mb-4 border-success border-opacity-25">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="badge bg-success bg-opacity-10 text-success border border-success px-2.5 py-1 rounded-pill small fw-semibold"><i class="bi bi-dot"></i> HACKER TELEMETRY CONNECTED</span>
                </div>
                <h2 class="fw-bold text-white mb-2"><i class="bi bi-terminal-fill text-success me-2"></i> Bug Bounty & VDP Portal</h2>
                <p class="text-secondary small mb-0">Jelajahi program keamanan target aktif yang dipublikasikan oleh perusahaan mitra dan kirimkan laporan celah kerentanan Anda.</p>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0 d-flex flex-column gap-2">
                <a href="ai_assistant.php" class="btn btn-h1-green py-2.5 px-4 shadow-sm"><i class="bi bi-cpu me-2"></i> Buka AI Hacker Copilot</a>
                <a href="messages.php" class="btn btn-sm btn-outline-success py-2 px-3 border-opacity-50"><i class="bi bi-chat-dots me-1"></i> Buka Live Chat Pesan</a>
            </div>
        </div>
    </div>

    
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Target VDP Aktif</span>
                    <span class="text-success fs-5"><i class="bi bi-shield-check"></i></span>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1">
                    <?php
                    $active_vdp_count = 0;
                    if (isset($conn)) {
                        $res_cnt = @$conn->query("SELECT COUNT(*) as cnt FROM programs WHERE verification_status NOT IN ('Closed', 'Rejected', 'Paused') OR verification_status IS NULL");
                        if ($res_cnt) { 
                            $active_vdp_count = $res_cnt->fetch_assoc()['cnt'] ?? 0; 
                        } else {
                            $res_cnt2 = @$conn->query("SELECT COUNT(*) as cnt FROM programs");
                            if ($res_cnt2) { $active_vdp_count = $res_cnt2->fetch_assoc()['cnt'] ?? 0; }
                        }
                    }
                    echo $active_vdp_count;
                    ?>
                </h1>
                <div class="text-success small fw-semibold"><i class="bi bi-check-circle me-1"></i> Siap diuji keamanannya</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Total Laporan Anda</span>
                    <span class="text-info fs-5"><i class="bi bi-file-earmark-text-fill"></i></span>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1"><?= $total_reports; ?></h1>
                <div class="text-info small fw-semibold"><i class="bi bi-send-check me-1"></i> Terkirim oleh Anda</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Total Payout (Earnings)</span>
                    <span class="text-success fs-5"><i class="bi bi-wallet2"></i></span>
                </div>
                <h1 class="fw-bold text-success display-6 mb-1">$<?= number_format($total_earnings_usd, 2); ?></h1>
                <div class="text-success small fw-semibold"><a href="tax_report.php" class="text-success text-decoration-none"><i class="bi bi-receipt me-1"></i> Lihat slip pajak & PPh</a></div>
            </div>
        </div>
    </div>

    
    <div class="card card-stat p-4 mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h5 class="fw-bold text-white mb-1"><i class="bi bi-shield-check text-success me-2"></i>Daftar Program VDP & Target Aktif</h5>
                <p class="text-secondary small mb-0">Pilih target yang tersedia untuk melakukan pengujian keamanan (Bug Bounty).</p>
            </div>
            <span class="badge bg-dark border border-secondary text-secondary px-3 py-2 rounded-pill">Live Programs</span>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Program / VDP</th>
                        <th>Status Ruang Lingkup</th>
                        <th class="text-end">Aksi Peneliti</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $vdp_exist = false;
                    if (isset($conn)) {
                        $q_vdp = @$conn->query("SELECT * FROM programs WHERE verification_status NOT IN ('Closed', 'Rejected', 'Paused') OR verification_status IS NULL ORDER BY id DESC");
                        if (!$q_vdp) {
                            $q_vdp = @$conn->query("SELECT * FROM programs ORDER BY id DESC");
                        }
                        
                        if ($q_vdp && $q_vdp->num_rows > 0) {
                            while ($vdp = $q_vdp->fetch_assoc()) {
                                $v_id = intval($vdp['id']);
                                $v_title = htmlspecialchars($vdp['title'] ?? ($vdp['program_title'] ?? 'Program VDP #' . $v_id), ENT_QUOTES, 'UTF-8');
                                $vdp_exist = true;

                                echo "<tr>";
                                echo "<td class='text-secondary font-monospace'>#{$v_id}</td>";
                                echo "<td class='fw-semibold text-white'>{$v_title}</td>";
                                echo "<td><span class='badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2.5 py-1'><i class='bi bi-dot'></i> Verified Scope</span></td>";
                                echo "<td class='text-end'>";
                                echo "<a href='submit_report.php?vdp_id={$v_id}' class='btn btn-sm btn-h1-green py-1.5 px-3'><i class='bi bi-send-fill me-1'></i> Kirim Laporan</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        }
                    }

                    if (!$vdp_exist) {
                        echo "<tr><td colspan='4' class='text-center text-muted py-5'>Belum ada program VDP aktif yang tersedia saat ini (telah ditutup/dimatikan).</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="card card-stat p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h5 class="fw-bold text-white mb-1"><i class="bi bi-file-earmark-text-fill text-info me-2"></i>Riwayat Laporan Bug Anda</h5>
                <p class="text-secondary small mb-0">Daftar laporan kerentanan yang telah Anda kirimkan ke sistem.</p>
            </div>
            <span class="badge bg-dark border border-secondary text-secondary px-3 py-2 rounded-pill">My Submissions</span>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Laporan</th>
                        <th>Jenis Kerentanan</th>
                        <th>Status Penanganan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $has_reports = false;
                    if (isset($conn)) {
                        $r_cols = [];
                        $res_rc = @$conn->query("SHOW COLUMNS FROM reports");
                        if ($res_rc) { while ($rc = $res_rc->fetch_assoc()) { $r_cols[] = $rc['Field']; } }
                        $id_col = in_array('hacker_id', $r_cols) ? 'hacker_id' : (in_array('user_id', $r_cols) ? 'user_id' : null);
                        $title_col = in_array('report_title', $r_cols) ? 'report_title' : (in_array('title', $r_cols) ? 'title' : 'id');

                        if ($id_col) {
                            $stmt_r = $conn->prepare("SELECT id, {$title_col} as title, status FROM reports WHERE {$id_col} = ? ORDER BY id DESC LIMIT 15");
                            if ($stmt_r) {
                                $stmt_r->bind_param("i", $user_id);
                                $stmt_r->execute();
                                $res_r = $stmt_r->get_result();
                                if ($res_r && $res_r->num_rows > 0) {
                                    while ($rep = $res_r->fetch_assoc()) {
                                        $has_reports = true;
                                        $rid = intval($rep['id']);
                                        $rtitle = htmlspecialchars($rep['title'] ?? 'Laporan #' . $rid, ENT_QUOTES, 'UTF-8');
                                        $rstatus = htmlspecialchars($rep['status'] ?? 'Resolved', ENT_QUOTES, 'UTF-8');

                                        echo "<tr>";
                                        echo "<td class='text-secondary font-monospace'>#{$rid}</td>";
                                        echo "<td class='fw-semibold text-white'>{$rtitle}</td>";
                                        echo "<td class='text-secondary'>Umum</td>";
                                        echo "<td><span class='badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2.5 py-1'><i class='bi bi-dot'></i> {$rstatus}</span></td>";
                                        echo "</tr>";
                                    }
                                }
                            }
                        }
                    }

                    if (!$has_reports) {
                        echo "<tr><td colspan='4' class='text-center text-muted py-5'>Belum ada laporan kerentanan yang Anda kirimkan.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/native.js"></script>
</body>
</html>