<?php
require 'config.php';


$stat_programs = 12;
$stat_reports  = 340;
$stat_bounties = 48250;
$stat_hackers  = 120;
if (isset($conn)) {
    $r = @$conn->query("SELECT COUNT(*) c FROM programs WHERE verification_status NOT IN ('Closed','Rejected','Paused')");
    if ($r) { $stat_programs = max(1, intval($r->fetch_assoc()['c'])); }
    $r = @$conn->query("SELECT COUNT(*) c, COALESCE(SUM(reward),0) s FROM reports");
    if ($r) { $row = $r->fetch_assoc(); $stat_reports = max(1, intval($row['c'])); $stat_bounties = floatval($row['s']); }
    $r = @$conn->query("SELECT COUNT(*) c FROM users");
    if ($r) { $stat_hackers = max(1, intval($r->fetch_assoc()['c'])); }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HackerCrowd — Continuous Threat Exposure Platform</title>
    <meta name="description" content="Platform bug bounty & VDP dengan AI HackerCrowd. Temukan, validasi, dan perbaiki kerentanan yang benar-benar berdampak.">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark navbar-custom px-4 py-3 fixed-top" data-testid="main-navbar">
    <div class="container-fluid" style="max-width: 1280px;">
        <a class="navbar-brand d-flex align-items-center gap-2" href="index.php" data-testid="brand-logo">
            <span class="logo-mark"><img src="assets/img/logo.svg" alt="HackerCrowd" width="30" height="30"></span>
            <span class="fs-5">Hacker<span class="text-success">Crowd</span></span>
        </a>
        <div class="d-flex align-items-center gap-4">
            <a href="#platform" class="nav-link-quiet d-none d-lg-inline">Platform</a>
            <a href="#how" class="nav-link-quiet d-none d-lg-inline">Cara Kerja</a>
            <a href="leaderboard.php" class="nav-link-quiet d-none d-lg-inline">Leaderboard</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] == 'owner'): ?>
                    <a href="owner_dashboard.php" class="btn btn-sm btn-outline-glass" data-testid="nav-dashboard-btn">Dashboard Owner</a>
                <?php elseif ($_SESSION['role'] == 'company'): ?>
                    <a href="company_dashboard.php" class="btn btn-sm btn-outline-glass" data-testid="nav-dashboard-btn">Dashboard Company</a>
                <?php else: ?>
                    <a href="dashboard.php" class="btn btn-sm btn-outline-glass" data-testid="nav-dashboard-btn">Dashboard Hacker</a>
                <?php endif; ?>
                <a href="logout.php" class="btn btn-sm btn-h1-green" data-testid="nav-logout-btn">Keluar</a>
            <?php else: ?>
                <a href="login.php" class="nav-link-quiet" data-testid="nav-login-link">Login</a>
                <a href="register.php" class="btn btn-sm btn-h1-green" data-testid="nav-get-started-btn">Get Started</a>
            <?php endif; ?>
        </div>
    </div>
</nav>


<header class="hero-section">
    <div class="aurora-orb orb-cyan"></div>
    <div class="aurora-orb orb-magenta"></div>

    <div class="floating-code" style="top: 20%; left: 4%;" data-parallax="0.06">$_SESSION['role'] = 'hacker';
if($auth) { grant_access(); }
// Payload: ' OR 1=1 --</div>
    <div class="floating-code" style="bottom: 16%; right: 6%; text-align: right;" data-parallax="0.09">POST /api/v1/vdp/submit HTTP/1.1
Host: hackercrowd.local
Authorization: Bearer sec_token_99x</div>

    <div class="hero-inner">
        <div>
            <div class="hero-kicker">Continuous Threat Exposure <span class="cursor-blink"></span></div>
            <h1 class="hero-title">
                <span class="hero-line d-1"><span>Not every</span></span>
                <span class="hero-line d-2 line-outline"><span>vulnerability</span></span>
                <span class="hero-line d-3"><span>matters.</span></span>
                <span class="hero-line d-4 line-signal"><span>Fix the ones that do.</span></span>
            </h1>
            <p class="hero-sub hero-fade">
                HackerCrowd menghubungkan perusahaan dengan peneliti keamanan terbaik —
                didukung AI HackerCrowd untuk validasi, mitigasi, dan payload analysis secara real-time.
            </p>
            <div class="hero-cta-row hero-fade">
                <a href="register.php" class="btn btn-glow-green" data-testid="hero-get-started-btn">Mulai Berburu <i class="bi bi-arrow-right ms-2"></i></a>
                <a href="#platform" class="btn btn-outline-glass" data-testid="hero-explore-btn">Jelajahi Platform</a>
            </div>
            <div class="hero-meta hero-fade">
                <div><b data-count="<?= $stat_programs ?>" data-testid="meta-programs">0</b>Program Aktif</div>
                <div><b data-count="<?= $stat_hackers ?>" data-testid="meta-hackers">0</b>Researcher</div>
                <div><b data-count="<?= number_format($stat_bounties, 0, '', '') ?>" data-prefix="$" data-testid="meta-bounties">$0</b>Bounty Dibayar</div>
            </div>
        </div>

        <div class="terminal-window" data-parallax="0.04" data-testid="hero-terminal">
            <div class="terminal-bar">
                <span class="terminal-dot r"></span>
                <span class="terminal-dot y"></span>
                <span class="terminal-dot g"></span>
                <span class="terminal-title">hc — copilot session</span>
            </div>
            <div class="terminal-body"><span class="p">$</span> <span class="cmd">hc scan --target acme-corp</span>
<span class="ok">[✓]</span> 214 assets discovered
<span class="ok">[✓]</span> 3 critical exposures validated
<span class="warn">[!]</span> SQLi confirmed on <span class="val">/api/v2/login</span>

<span class="p">$</span> <span class="cmd">hc report submit --sev critical</span>
<span class="ok">→ Report #1337 terkirim untuk triase</span>
<span class="ok">→ Bounty queued:</span> <span class="val">$1,500.00</span></div>
        </div>
    </div>
</header>


<div class="marquee" aria-hidden="true">
    <div class="marquee-track">
        <?php for ($i = 0; $i < 2; $i++): ?>
        <span class="marquee-item">Bug Bounty <i>◆</i></span>
        <span class="marquee-item">VDP Programs <i>◆</i></span>
        <span class="marquee-item">AI HackerCrowd <i>◆</i></span>
        <span class="marquee-item">Threat Exposure <i>◆</i></span>
        <span class="marquee-item">Responsible Disclosure <i>◆</i></span>
        <span class="marquee-item">Instant Payout <i>◆</i></span>
        <?php endfor; ?>
    </div>
</div>


<section class="section" id="platform">
    <div class="section-inner">
        <div class="section-head" data-reveal>
            <div class="section-kicker">Platform</div>
            <h2 class="section-title">Satu command center untuk seluruh siklus keamanan.</h2>
            <p class="section-desc">Dari recon hingga payout — setiap peran punya portal khusus: Hacker, Company, dan Owner.</p>
        </div>

        <div class="bento-grid">
            <div class="bento-item b-hero">
                <div class="bento-icon"><i class="bi bi-cpu"></i></div>
                <div class="bento-tag">AI HackerCrowd</div>
                <h3 class="bento-title">AI HackerCrowd yang berpikir seperti attacker.</h3>
                <p class="bento-desc">Analisis payload, saran mitigasi, dan asisten eksplorasi kerentanan — langsung di dalam portal Anda.</p>
                <div class="bento-chat">
                    <span class="p">HackerCrowd AI&gt;</span> analisis payload ini: <span class="val">' OR 1=1 --</span><br>
                    <span class="p">→</span> Tautology-based SQLi. Bypass risiko: <span class="val">tinggi</span>.<br>
                    <span class="p">→</span> Mitigasi: prepared statement + WAF rule.
                </div>
            </div>

            <div class="bento-item b-wide">
                <div class="bento-tag">Live Programs</div>
                <h3 class="bento-title">Target terverifikasi, siap diuji.</h3>
                <ul class="bento-list">
                    <li><b>Acme Corp VDP</b><span class="amt">up to $2,000</span></li>
                    <li><b>Finara Bank Bounty</b><span class="amt">up to $5,000</span></li>
                    <li><b>Skyline Cloud</b><span class="amt">up to $1,200</span></li>
                </ul>
            </div>

            <div class="bento-item b-wide">
                <div class="bento-icon"><i class="bi bi-wallet2"></i></div>
                <div class="bento-tag">Payout</div>
                <div class="d-flex align-items-center gap-4">
                    <div class="bento-big-num">$</div>
                    <p class="bento-desc">Bounty transparan + slip pajak &amp; PPh otomatis untuk setiap payout yang cair.</p>
                </div>
            </div>

            <div class="bento-item b-third">
                <div class="bento-icon"><i class="bi bi-trophy"></i></div>
                <div class="bento-tag">Leaderboard</div>
                <h3 class="bento-title">Naik peringkat.</h3>
                <p class="bento-desc">Reputasi global untuk setiap laporan yang resolved.</p>
            </div>

            <div class="bento-item b-third">
                <div class="bento-icon"><i class="bi bi-chat-square-text"></i></div>
                <div class="bento-tag">Secure Messaging</div>
                <h3 class="bento-title">Koordinasi langsung.</h3>
                <p class="bento-desc">Diskusi laporan antara hacker, company, dan owner dalam satu thread.</p>
            </div>

            <div class="bento-item b-third">
                <div class="bento-icon"><i class="bi bi-shield-lock"></i></div>
                <div class="bento-tag">Owner Console</div>
                <h3 class="bento-title">Kontrol penuh.</h3>
                <p class="bento-desc">Audit trail, verifikasi program, dan moderasi laporan terpusat.</p>
            </div>
        </div>
    </div>
</section>


<section class="stats-band">
    <div class="stats-grid">
        <div class="stat-cell">
            <div class="stat-num" data-count="<?= $stat_programs ?>" data-testid="stat-programs">0</div>
            <div class="stat-label">Program VDP Aktif</div>
        </div>
        <div class="stat-cell">
            <div class="stat-num" data-count="<?= $stat_reports ?>" data-testid="stat-reports">0</div>
            <div class="stat-label">Laporan Masuk</div>
        </div>
        <div class="stat-cell">
            <div class="stat-num"><em data-count="<?= number_format($stat_bounties, 0, '', '') ?>" data-prefix="$" data-testid="stat-bounties">$0</em></div>
            <div class="stat-label">Total Bounty</div>
        </div>
        <div class="stat-cell">
            <div class="stat-num" data-count="<?= $stat_hackers ?>" data-suffix="+" data-testid="stat-hackers">0</div>
            <div class="stat-label">Security Researcher</div>
        </div>
    </div>
</section>


<section class="section" id="how">
    <div class="section-inner">
        <div class="section-head" data-reveal>
            <div class="section-kicker">Cara Kerja</div>
            <h2 class="section-title">Tiga langkah dari recon ke reward.</h2>
        </div>
        <div class="steps-grid">
            <div class="step-card">
                <span class="step-num">/ 01</span>
                <h3 class="step-title">Recon &amp; Scope</h3>
                <p class="step-desc">Pilih program VDP aktif, pahami ruang lingkup yang terverifikasi, dan mulai pengujian keamanan Anda.</p>
            </div>
            <div class="step-card">
                <span class="step-num">/ 02</span>
                <h3 class="step-title">Validate &amp; Report</h3>
                <p class="step-desc">Gunakan AI HackerCrowd untuk memvalidasi temuan, lalu kirim laporan terstruktur lengkap dengan bukti.</p>
            </div>
            <div class="step-card">
                <span class="step-num">/ 03</span>
                <h3 class="step-title">Triage &amp; Payout</h3>
                <p class="step-desc">Company meninjau, owner memverifikasi, dan bounty cair — lengkap dengan slip pajak otomatis.</p>
            </div>
        </div>
    </div>
</section>


<section class="section pt-0">
    <div class="section-inner">
        <div class="cta-panel" data-reveal>
            <div class="section-kicker justify-content-center" style="justify-content:center;">Siap Berburu?</div>
            <h2 class="cta-title">Hack with<br>purpose.</h2>
            <p class="cta-sub">Bergabung dengan komunitas peneliti keamanan dan mulai hasilkan bounty dari kerentanan yang benar-benar berdampak.</p>
            <div class="d-flex justify-content-center gap-3 flex-wrap">
                <a href="register.php" class="btn btn-glow-green" data-testid="cta-register-btn">Daftar sebagai Hacker</a>
                <a href="register.php" class="btn btn-outline-glass" data-testid="cta-company-btn">Publikasikan Program</a>
            </div>
        </div>
    </div>
</section>


<footer class="site-footer">
    <div class="footer-inner">
        <div class="footer-brand">
            <a class="d-flex align-items-center gap-2 text-decoration-none" href="index.php">
                <span class="logo-mark"><img src="assets/img/logo.svg" alt="HackerCrowd" width="28" height="28"></span>
                <span class="fw-bold text-white fs-5">Hacker<span class="text-success">Crowd</span></span>
            </a>
            <p class="footer-desc">Platform bug bounty &amp; VDP dengan AI HackerCrowd. Continuous threat exposure, dari komunitas untuk komunitas.</p>
        </div>
        <div class="footer-links">
            <div class="footer-col">
                <h6>Platform</h6>
                <a href="dashboard.php">Hacker Portal</a>
                <a href="company_dashboard.php">Company Portal</a>
                <a href="leaderboard.php">Leaderboard</a>
            </div>
            <div class="footer-col">
                <h6>Tools</h6>
                <a href="ai_assistant.php">AI HackerCrowd</a>
                <a href="ai_payload.php">Payload Analyzer</a>
                <a href="ai_mitigation.php">Mitigation AI</a>
            </div>
            <div class="footer-col">
                <h6>Akun</h6>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <span>© 2026 HackerCrowd</span>
        <span>Continuous Threat Exposure Platform</span>
    </div>
</footer>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/native.js"></script>
</body>
</html>
