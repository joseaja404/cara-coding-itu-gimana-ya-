<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


error_reporting(E_ALL);
ini_set('display_errors', 0);


if (file_exists('config.php')) {
    require_once 'config.php';
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!empty($username) && !empty($password)) {
        if (isset($conn)) {
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
            if ($stmt) {
                $stmt->bind_param("ss", $username, $username);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($row = $result->fetch_assoc()) {
                    
                    $is_valid = false;
                    if (password_verify($password, $row['password']) || $password === $row['password'] || md5($password) === $row['password']) {
                        $is_valid = true;
                    }

                    if ($is_valid) {
                        
                        $_SESSION['user_id'] = $row['id'];
                        $_SESSION['username'] = $row['username'];
                        $_SESSION['role'] = strtolower($row['role'] ?? 'hacker');
                        $_SESSION['email'] = $row['email'] ?? '';

                        
                        $role = $_SESSION['role'];
                        if ($role === 'owner') {
                            header("Location: owner_dashboard.php");
                        } elseif ($role === 'company') {
                            header("Location: company_dashboard.php");
                        } else {
                            header("Location: dashboard.php");
                        }
                        exit;
                    } else {
                        $error = "Password yang Anda masukkan salah.";
                    }
                } else {
                    $error = "Akun dengan username atau email tersebut tidak ditemukan.";
                }
                $stmt->close();
            } else {
                $error = "Gagal memproses kueri database.";
            }
        } else {
            $error = "Koneksi database tidak tersedia.";
        }
    } else {
        $error = "Username dan password wajib diisi.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - HackerCrowd</title>

<style>
        :root {
            --bg-deep: #020408;
            --card-bg: rgba(11, 18, 33, 0.75);
            --border-glass: rgba(255, 255, 255, 0.08);
            --neon-green: #10b981;
        }
        body { 
            background-color: var(--bg-deep); 
            color: #f8fafc; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; 
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: radial-gradient(circle at 50% 20%, rgba(16, 185, 129, 0.08) 0%, transparent 50%);
        }
        .card-auth { 
            background: var(--card-bg); 
            border: 1px solid var(--border-glass); 
            border-radius: 20px; 
            backdrop-filter: blur(20px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.6);
            width: 100%;
            max-width: 440px;
            padding: 40px;
        }
        .btn-h1-green { 
            background: linear-gradient(135deg, #10b981 0%, #059669 100%); 
            color: #ffffff; 
            font-weight: 600; 
            border-radius: 12px; 
            border: none;
            padding: 12px;
        }
        .btn-h1-green:hover { color: #fff; opacity: 0.9; }
        .form-control {
            background-color: rgba(4, 7, 14, 0.8) !important;
            border-color: rgba(255, 255, 255, 0.1) !important;
            color: #fff !important;
            border-radius: 12px;
            padding: 12px 16px;
        }
        .form-control:focus {
            border-color: var(--neon-green) !important;
            box-shadow: 0 0 0 0.25rem rgba(16, 185, 129, 0.25) !important;
        }
    </style>
<link rel="stylesheet" href="assets/css/native.css">
</head>
<body>

<div class="card card-auth">
    <div class="text-center mb-4">
        <i class="bi bi-shield-shaded text-success fs-1"></i>
        <h3 class="fw-bold text-white mt-2">Hacker<span class="text-success">Crowd</span></h3>
        <p class="text-secondary small">Masuk ke portal keamanan & manajemen VDP</p>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger bg-danger bg-opacity-10 border border-danger text-danger rounded-3 p-3 mb-4 small">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label class="form-label text-secondary small text-uppercase fw-bold">Username / Email</label>
            <input type="text" name="username" class="form-control" placeholder="Masukkan username atau email" required autocomplete="off">
        </div>

        <div class="mb-4">
            <label class="form-label text-secondary small text-uppercase fw-bold">Password</label>
            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
        </div>

        <button type="submit" class="btn btn-h1-green w-100 mb-3"><i class="bi bi-box-arrow-in-right me-2"></i> Masuk Sekarang</button>
        
        <div class="text-center text-secondary small">
            Belum punya akun? <a href="register.php" class="text-success text-decoration-none fw-semibold">Daftar di sini</a>
        </div>
    </form>
</div>

<script src="assets/js/native.js"></script>
</body>
</html>