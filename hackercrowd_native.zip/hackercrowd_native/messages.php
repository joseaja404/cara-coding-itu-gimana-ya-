<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id   = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$receiver_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : null;


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    $receiver_id = intval($_POST['receiver_id']);
    $message_text = trim($_POST['message']);

    if (!empty($message_text) && $receiver_id > 0 && $receiver_id != $user_id) {
        $stmt_chk = $conn->prepare("SELECT role FROM users WHERE id = ?");
        $stmt_chk->bind_param("i", $receiver_id);
        $stmt_chk->execute();
        $target_role = $stmt_chk->get_result()->fetch_assoc()['role'] ?? '';

        $allow_send = true;
        if ($user_role != 'owner' && $target_role == 'owner') {
            $stmt_owner_init = $conn->prepare("SELECT id FROM messages WHERE sender_id = ? AND receiver_id = ?");
            $stmt_owner_init->bind_param("ii", $receiver_id, $user_id);
            $stmt_owner_init->execute();
            if ($stmt_owner_init->get_result()->num_rows == 0) {
                $allow_send = false; 
            }
        }

        if ($allow_send) {
            $stmt_send = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
            $stmt_send->bind_param("iis", $user_id, $receiver_id, $message_text);
            $stmt_send->execute();
            
            log_activity($conn, $user_id, "SEND_MESSAGE", "Mengirim pesan kepada user ID: $receiver_id");
            header("Location: messages.php?user_id=" . $receiver_id);
            exit;
        }
    }
}



if ($user_role == 'owner') {
    $stmt_list = $conn->prepare("SELECT id, username, role, profile_pic FROM users WHERE id != ? ORDER BY role ASC, username ASC");
    $stmt_list->bind_param("i", $user_id);
    $stmt_list->execute();
    $users_list = $stmt_list->get_result();
} else {
    $stmt_list = $conn->prepare("SELECT DISTINCT u.id, u.username, u.role, u.profile_pic 
                                FROM users u 
                                WHERE u.id != ? 
                                  AND (u.role != 'owner' OR u.id IN (
                                      SELECT sender_id FROM messages WHERE receiver_id = ? AND sender_id IN (SELECT id FROM users WHERE role = 'owner')
                                  ))
                                ORDER BY u.role ASC, u.username ASC");
    $stmt_list->bind_param("ii", $user_id, $user_id);
    $stmt_list->execute();
    $users_list = $stmt_list->get_result();
}


$active_user = null;
$messages_result = null;
if ($receiver_id) {
    $stmt_u = $conn->prepare("SELECT id, username, role, profile_pic FROM users WHERE id = ?");
    $stmt_u->bind_param("i", $receiver_id);
    $stmt_u->execute();
    $active_user = $stmt_u->get_result()->fetch_assoc();

    if ($active_user) {
        if ($user_role != 'owner' && $active_user['role'] == 'owner') {
            $stmt_chk_init = $conn->prepare("SELECT id FROM messages WHERE sender_id = ? AND receiver_id = ?");
            $stmt_chk_init->bind_param("ii", $receiver_id, $user_id);
            $stmt_chk_init->execute();
            if ($stmt_chk_init->get_result()->num_rows == 0) {
                header("Location: messages.php");
                exit;
            }
        }

        $stmt_read = $conn->prepare("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ?");
        $stmt_read->bind_param("ii", $user_id, $receiver_id);
        $stmt_read->execute();

        $stmt_msg = $conn->prepare("SELECT * FROM messages 
                                     WHERE (sender_id = ? AND receiver_id = ?) 
                                        OR (sender_id = ? AND receiver_id = ?) 
                                     ORDER BY created_at ASC");
        $stmt_msg->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
        $stmt_msg->execute();
        $messages_result = $stmt_msg->get_result();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pusat Pesan - HackerCrowd Project</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark px-4 py-3 border-bottom border-dark bg-dark">
    <a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
        <i class="bi bi-shield-lock-fill text-success fs-3 me-2"></i> Hacker<span class="text-success">Crowd</span> Project
    </a>
    <div class="ms-auto d-flex align-items-center gap-2">
        <?php if($user_role == 'owner'): ?>
            <a href="owner_dashboard.php" class="btn btn-outline-light btn-sm rounded-pill px-3 shadow-sm">
                <i class="bi bi-arrow-left-circle me-1"></i> Dashboard Owner
            </a>
        <?php else: ?>
            <a href="dashboard.php" class="btn btn-outline-light btn-sm rounded-pill px-3 shadow-sm">
                <i class="bi bi-arrow-left-circle me-1"></i> Dashboard Utama
            </a>
        <?php endif; ?>
        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-3 shadow-sm"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
</nav>

<div class="container-fluid px-4 my-4">
    <div class="row chat-wrapper">
        
        
        <div class="col-md-4 col-lg-3 p-0 sidebar-pane">
            <div class="sidebar-header">
                <h5 class="fw-bold text-white mb-1"><i class="bi bi-chat-text-fill text-success me-2"></i>Pesan Langsung</h5>
                <p class="text-secondary small mb-0">Pilih kontak untuk mulai berdiskusi</p>
            </div>
            
            <div class="contact-list">
                <?php if ($users_list && $users_list->num_rows > 0): ?>
                    <?php while($c = $users_list->fetch_assoc()): ?>
                        <a href="messages.php?user_id=<?= $c['id'] ?>" class="contact-card <?= ($receiver_id == $c['id']) ? 'active' : '' ?>">
                            <?php if (!empty($c['profile_pic']) && file_exists('uploads/' . $c['profile_pic'])): ?>
                                <img src="uploads/<?= htmlspecialchars($c['profile_pic']) ?>" class="avatar-sm me-3" alt="Avatar">
                            <?php else: ?>
                                <img src="https://api.dicebear.com/7.x/identicon/svg?seed=<?= urlencode($c['username']) ?>" class="avatar-sm me-3 bg-secondary" alt="Avatar">
                            <?php endif; ?>
                            <div class="overflow-hidden">
                                <h6 class="mb-0 text-white text-truncate fw-semibold"><?= htmlspecialchars($c['username']) ?></h6>
                                <span class="badge bg-<?= $c['role'] == 'owner' ? 'danger' : ($c['role'] == 'company' ? 'primary' : 'success') ?> bg-opacity-75 mt-1" style="font-size: 0.65rem;"><?= ucfirst($c['role']) ?></span>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="p-4 text-center text-secondary small">Belum ada kontak tersedia.</div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="col-md-8 col-lg-9 p-0 chat-pane">
            <?php if ($active_user): ?>
                
                
                <div class="chat-header">
                    <?php if (!empty($active_user['profile_pic']) && file_exists('uploads/' . $active_user['profile_pic'])): ?>
                        <img src="uploads/<?= htmlspecialchars($active_user['profile_pic']) ?>" class="avatar me-3" alt="Avatar">
                    <?php else: ?>
                        <img src="https://api.dicebear.com/7.x/identicon/svg?seed=<?= urlencode($active_user['username']) ?>" class="avatar me-3 bg-secondary" alt="Avatar">
                    <?php endif; ?>
                    <div>
                        <h5 class="mb-0 text-white fw-bold"><?= htmlspecialchars($active_user['username']) ?></h5>
                        <span class="badge bg-secondary bg-opacity-50 text-light mt-1" style="font-size: 0.7rem;">Role: <?= ucfirst($active_user['role']) ?></span>
                    </div>
                </div>

                
                <div class="chat-body" id="chatBody">
                    <?php if ($messages_result && $messages_result->num_rows > 0): ?>
                        <?php while($m = $messages_result->fetch_assoc()): ?>
                            <div class="msg-bubble <?= ($m['sender_id'] == $user_id) ? 'msg-sent' : 'msg-received' ?>">
                                <p class="mb-0"><?= nl2br(htmlspecialchars($m['message'])) ?></p>
                                <span class="msg-time"><?= date("H:i", strtotime($m['created_at'])) ?></span>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center text-secondary my-auto">
                            <i class="bi bi-chat-heart display-4 d-block mb-3 text-muted opacity-50"></i>
                            <h6 class="text-white fw-semibold">Belum ada riwayat pesan</h6>
                            <p class="small text-muted mb-0">Kirim pesan pertama Anda untuk memulai percakapan aman dengan <?= htmlspecialchars($active_user['username']) ?>.</p>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="chat-footer">
                    <form method="POST" class="d-flex align-items-center gap-3">
                        <input type="hidden" name="send_message" value="1">
                        <input type="hidden" name="receiver_id" value="<?= $active_user['id'] ?>">
                        <input type="text" name="message" class="form-control chat-input" placeholder="Tulis pesan atau diskusi keamanan..." autocomplete="off" required>
                        <button type="submit" class="btn btn-success rounded-circle d-flex align-items-center justify-content-center shadow" style="width: 48px; height: 48px; flex-shrink: 0;">
                            <i class="bi bi-send-fill fs-5"></i>
                        </button>
                    </form>
                </div>

            <?php else: ?>
                
                <div class="text-center text-secondary my-auto p-5">
                    <div class="bg-dark rounded-circle d-inline-flex p-4 mb-3 border border-secondary shadow-sm">
                        <i class="bi bi-chat-square-dots display-4 text-success"></i>
                    </div>
                    <h4 class="text-white fw-bold">Pusat Pesan Keamanan</h4>
                    <p class="small text-muted mx-auto" style="max-width: 400px;">Pilih salah satu kontak di sebelah kiri untuk membuka ruang obrolan privat secara real-time.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script>
    // Auto-scroll ke pesan paling bawah secara otomatis saat halaman dimuat
    const chatBody = document.getElementById('chatBody');
    if (chatBody) {
        chatBody.scrollTop = chatBody.scrollHeight;
    }
</script>
<script src="assets/js/native.js"></script>
</body>
</html>