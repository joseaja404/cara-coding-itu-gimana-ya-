<?php
require 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    
    
    $role = isset($_POST['role']) ? trim($_POST['role']) : 'hacker';
    if ($role != 'hacker' && $role != 'company') {
        $role = 'hacker';
    }

    
    if (empty($username) || empty($email) || empty($password)) {
        $error = "Semua kolom harus diisi!";
    } else {
        
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $error = "Email sudah terdaftar. Silakan gunakan email lain atau login.";
        } else {
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            
            $stmt_insert = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt_insert->bind_param("ssss", $username, $email, $hashed_password, $role);

            if ($stmt_insert->execute()) {
                $success = "Registrasi berhasil! Silakan <a href='login.php' class='text-success fw-bold'>Masuk ke Akun</a>.";
            } else {
                $error = "Terjadi kesalahan sistem. Silakan coba lagi.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - HackerCrowd Project</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="d-flex align-items-center justify-content-center vh-100">

<div class="container" style="max-width: 440px;">
    <div class="text-center mb-4">
        <a href="index.php" class="text-decoration-none d-inline-flex align-items-center">
            <i class="bi bi-shield-shaded text-success fs-2 me-2"></i>
            <span class="fw-bold text-white fs-3">Hacker<span class="text-success">Crowd</span></span>
        </a>
    </div>

    <div class="card card-auth p-4">
        <h4 class="fw-bold text-white mb-1">Daftar Akun Baru</h4>
        <p class="text-secondary small mb-4">Pilih peran Anda untuk bergabung dengan platform HackerCrowd.</p>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger py-2 small text-center"><?= $error ?></div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success py-2 small text-center"><?= $success ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Username</label>
                <input type="text" name="username" class="form-control bg-dark text-white border-secondary" placeholder="Nama Pengguna" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Email</label>
                <input type="email" name="email" class="form-control bg-dark text-white border-secondary" placeholder="nama@domain.com" required>
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Password</label>
                <input type="password" name="password" class="form-control bg-dark text-white border-secondary" placeholder="••••••••" required>
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Role / Peran</label>
                <select name="role" class="form-select bg-dark text-white border-secondary">
                    <option value="hacker">Hacker (Peneliti Keamanan)</option>
                    <option value="company">Company (Perusahaan / Pemilik Program)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-h1-green w-100 py-2">Daftar Akun</button>
        </form>

        <div class="text-center mt-4 pt-3 border-top border-secondary border-opacity-25">
            <span class="text-secondary small">Sudah punya akun?</span> 
            <a href="login.php" class="text-success fw-semibold text-decoration-none small">Masuk di sini</a>
        </div>
    </div>
</div>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/native.js"></script>
</body>
</html>