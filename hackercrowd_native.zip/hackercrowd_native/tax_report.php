<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


if (file_exists('config.php')) {
    require_once 'config.php';
} else {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}


if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'hacker') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success_msg = "";
$error_msg = "";




if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_tax_profile') {
    $new_real_name = trim($_POST['real_name'] ?? '');
    $new_ptkp_status = trim($_POST['ptkp_status'] ?? 'TK/0');

    if (!empty($new_real_name) && isset($conn)) {
        
        $u_cols = [];
        $res_uc = @$conn->query("SHOW COLUMNS FROM users");
        if ($res_uc) {
            while ($uc = $res_uc->fetch_assoc()) { $u_cols[] = $uc['Field']; }
        }

        
        $target_col = in_array('fullname', $u_cols) ? 'fullname' : (in_array('name', $u_cols) ? 'name' : 'real_name');
        if (!in_array($target_col, $u_cols)) {
            @$conn->query("ALTER TABLE users ADD COLUMN fullname VARCHAR(255) DEFAULT ''");
            $target_col = 'fullname';
        }

        
        if (!in_array('ptkp_status', $u_cols)) {
            @$conn->query("ALTER TABLE users ADD COLUMN ptkp_status VARCHAR(20) DEFAULT 'TK/0'");
        }

        $stmt_up = $conn->prepare("UPDATE users SET {$target_col} = ?, ptkp_status = ? WHERE id = ?");
        if ($stmt_up) {
            $stmt_up->bind_param("ssi", $new_real_name, $new_ptkp_status, $user_id);
            if ($stmt_up->execute()) {
                $success_msg = "Profil Wajib Pajak (Nama & Status PTKP) berhasil diperbarui!";
            } else {
                $error_msg = "Gagal menyimpan perubahan profil ke database.";
            }
        }
    } else {
        $error_msg = "Nama Wajib Pajak tidak boleh kosong!";
    }
}


$real_name = $_SESSION['username'] ?? 'Elite Security Researcher';
$ptkp_status = 'TK/0';

if (isset($conn)) {
    $res_u = @$conn->query("SELECT * FROM users WHERE id = $user_id");
    if ($res_u && $res_u->num_rows > 0) {
        $u_data = $res_u->fetch_assoc();
        $real_name = $u_data['fullname'] ?? ($u_data['name'] ?? ($u_data['real_name'] ?? ($u_data['username'] ?? $real_name)));
        $ptkp_status = $u_data['ptkp_status'] ?? 'TK/0';
    }
}




$ptkp_values = [
    'TK/0' => 54000000,
    'TK/1' => 58500000,
    'TK/2' => 63000000,
    'TK/3' => 67500000,
    'K/0'  => 58500000,
    'K/1'  => 63000000,
    'K/2'  => 67500000,
    'K/3'  => 72000000
];
$ptkp_amount = $ptkp_values[$ptkp_status] ?? 54000000;




$kurs_usd_idr = 15500; 
$rate_status_label = "Kurs Acuan Fiskal Standar";

$api_url = "https://api.exchangerate-api.com/v4/latest/USD";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 2);
$response = curl_exec($ch);
curl_close($ch);

if ($response) {
    $data = json_decode($response, true);
    if (isset($data['rates']['IDR'])) {
        $kurs_usd_idr = floatval($data['rates']['IDR']);
        $rate_status_label = "Kurs Real-Time BI/Pasar Live";
    }
}




$total_earnings_usd = 0;
$paid_reports = [];

if (isset($conn)) {
    $chk_rep = @$conn->query("SHOW TABLES LIKE 'reports'");
    if ($chk_rep && $chk_rep->num_rows > 0) {
        $r_cols = [];
        $res_rc = @$conn->query("SHOW COLUMNS FROM reports");
        if ($res_rc) {
            while ($rc = $res_rc->fetch_assoc()) { $r_cols[] = $rc['Field']; }
        }

        if (in_array('hacker_id', $r_cols)) {
            $q_rep = @$conn->query("SELECT * FROM reports WHERE hacker_id = '$user_id' ORDER BY id DESC");
        } elseif (in_array('user_id', $r_cols)) {
            $q_rep = @$conn->query("SELECT * FROM reports WHERE user_id = '$user_id' ORDER BY id DESC");
        } else {
            $q_rep = @$conn->query("SELECT * FROM reports ORDER BY id DESC");
        }

        if ($q_rep && $q_rep->num_rows > 0) {
            while ($r = $q_rep->fetch_assoc()) {
                $status = $r['status'] ?? 'Pending';
                $raw_reward = $r['reward'] ?? ($r['bounty'] ?? ($status === 'Resolved' ? '$350.00' : '$0.00'));
                preg_match('/[0-9\.]+/', str_replace([',', '$'], '', $raw_reward), $matches);
                $amount = isset($matches[0]) ? floatval($matches[0]) : ($status === 'Resolved' ? 350.00 : 0.00);

                if ($status === 'Resolved' || $amount > 0) {
                    $r['payout_amount'] = $amount;
                    $total_earnings_usd += $amount;
                    $paid_reports[] = $r;
                }
            }
        }
    }
}




$total_bruto_idr = $total_earnings_usd * $kurs_usd_idr;
$penghasilan_netto_idr = $total_bruto_idr * 0.50; 
$pkp_idr = max(0, $penghasilan_netto_idr - $ptkp_amount);

$pph_terutang_idr = 0;
if ($pkp_idr > 0) {
    if ($pkp_idr <= 60000000) {
        $pph_terutang_idr = $pkp_idr * 0.05;
    } elseif ($pkp_idr <= 250000000) {
        $pph_terutang_idr = (60000000 * 0.05) + (($pkp_idr - 60000000) * 0.15);
    } elseif ($pkp_idr <= 500000000) {
        $pph_terutang_idr = (60000000 * 0.05) + (190000000 * 0.15) + (($pkp_idr - 250000000) * 0.25);
    } else {
        $pph_terutang_idr = (60000000 * 0.05) + (190000000 * 0.15) + (250000000 * 0.25) + (($pkp_idr - 500000000) * 0.30);
    }
}

$pph_terutang_usd = $kurs_usd_idr > 0 ? ($pph_terutang_idr / $kurs_usd_idr) : 0;
$net_payout_usd = $total_earnings_usd - $pph_terutang_usd;

$tax_year = date('Y');
$slip_code = 'PPh-IDR-' . strtoupper(substr(md5($user_id . $tax_year . date('Ymd')), 0, 8));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pajak PPh 21 - <?= htmlspecialchars($real_name); ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<div class="aurora-orb-dash orb-dash-1"></div>
<div class="aurora-orb-dash orb-dash-2"></div>


<nav class="navbar navbar-expand-lg navbar-dark navbar-custom px-4 py-3 sticky-top no-print">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="dashboard.php">
            <i class="bi bi-shield-shaded text-success fs-3 me-2"></i>
            <span class="fs-4">Hacker<span class="text-success">Crowd</span></span>
            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 ms-3 px-3 py-1 fs-6 rounded-pill">PPh 21 Tax Gateway</span>
        </a>
        <div class="d-flex align-items-center gap-3">
            <a href="dashboard.php" class="btn btn-sm btn-outline-light px-3 rounded-pill py-2"><i class="bi bi-arrow-left me-1"></i> Kembali ke Dashboard</a>
            <button onclick="window.print()" class="btn btn-sm btn-h1-green px-4 py-2"><i class="bi bi-printer-fill me-2"></i> Cetak Slip Pajak SPT</button>
        </div>
    </div>
</nav>

<div class="container my-5" style="max-width: 1000px;">
    
    <?php if (!empty($success_msg)): ?>
        <div class="alert alert-success bg-success bg-opacity-15 border border-success text-success mb-4 rounded-3 py-3 px-4 no-print">
            <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($success_msg); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div class="alert alert-danger bg-danger bg-opacity-15 border border-danger text-danger mb-4 rounded-3 py-3 px-4 no-print">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error_msg); ?>
        </div>
    <?php endif; ?>

    
    <div class="card card-stat p-4 mb-4 border-info border-opacity-25 no-print">
        <div class="d-flex align-items-center justify-content-between mb-2">
            <h6 class="fw-bold text-white mb-0"><i class="bi bi-person-badge text-info me-2"></i>Pengaturan Wajib Pajak & Status PTKP PPh 21</h6>
            <span class="badge bg-info bg-opacity-10 text-info border border-info border-opacity-25 px-2.5 py-1">Manual Override</span>
        </div>
        <p class="text-secondary small mb-3">Sesuaikan nama lengkap dan status PTKP (Penghasilan Tidak Kena Pajak) Anda agar kalkulasi PPh 21 presisi sesuai tanggungan.</p>
        
        <form method="POST" action="" class="row g-3">
            <input type="hidden" name="action" value="update_tax_profile">
            <div class="col-md-7">
                <label class="form-label text-secondary small">Nama Lengkap (Sesuai KTP/NPWP)</label>
                <input type="text" name="real_name" value="<?= htmlspecialchars($real_name); ?>" class="form-control bg-dark text-white border-secondary" placeholder="Masukkan nama lengkap..." required>
            </div>
            <div class="col-md-3">
                <label class="form-label text-secondary small">Status PTKP</label>
                <select name="ptkp_status" class="form-select bg-dark text-white border-secondary">
                    <option value="TK/0" <?= $ptkp_status === 'TK/0' ? 'selected' : ''; ?>>TK/0 (Rp 54 Juta)</option>
                    <option value="TK/1" <?= $ptkp_status === 'TK/1' ? 'selected' : ''; ?>>TK/1 (Rp 58.5 Juta)</option>
                    <option value="TK/2" <?= $ptkp_status === 'TK/2' ? 'selected' : ''; ?>>TK/2 (Rp 63 Juta)</option>
                    <option value="TK/3" <?= $ptkp_status === 'TK/3' ? 'selected' : ''; ?>>TK/3 (Rp 67.5 Juta)</option>
                    <option value="K/0" <?= $ptkp_status === 'K/0' ? 'selected' : ''; ?>>K/0 (Rp 58.5 Juta)</option>
                    <option value="K/1" <?= $ptkp_status === 'K/1' ? 'selected' : ''; ?>>K/1 (Rp 63 Juta)</option>
                    <option value="K/2" <?= $ptkp_status === 'K/2' ? 'selected' : ''; ?>>K/2 (Rp 67.5 Juta)</option>
                    <option value="K/3" <?= $ptkp_status === 'K/3' ? 'selected' : ''; ?>>K/3 (Rp 72 Juta)</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-outline-info w-100 fw-semibold py-2"><i class="bi bi-save2 me-1"></i> Simpan</button>
            </div>
        </form>
    </div>

    
    <div class="card-stat p-5 mb-4 border-success border-opacity-25">
        <div class="row align-items-center border-bottom border-secondary pb-4 mb-4">
            <div class="col-md-8">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="badge bg-success bg-opacity-15 text-success border border-success px-3 py-1 rounded-pill">Bukti Rekapitulasi PPh Pasal 21 / Pekerjaan Bebas</span>
                    <span class="text-secondary font-monospace small">Ref: <?= $slip_code; ?></span>
                </div>
                <h2 class="fw-bold text-white mb-1"><i class="bi bi-receipt text-success me-2"></i>Laporan Pajak Penghasilan (SPT) Bug Bounty</h2>
                <p class="text-secondary small mb-0">Dokumen resmi atas nama <strong><?= htmlspecialchars($real_name); ?></strong> (Status PTKP: <strong><?= $ptkp_status; ?></strong>) untuk tahun fiskal <?= $tax_year; ?>.</p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-lg-0 no-print">
                <button onclick="window.print()" class="btn btn-h1-green px-4 py-2.5 w-100">
                    <i class="bi bi-file-earmark-pdf-fill me-2"></i> Cetak / Simpan PDF
                </button>
            </div>
        </div>

        
        <div class="row g-4 mb-4">
            <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-dark bg-opacity-50 border border-secondary border-opacity-25">
                    <span class="text-secondary small text-uppercase d-block mb-1">Wajib Pajak & PTKP</span>
                    <h5 class="fw-bold text-white mb-1"><?= htmlspecialchars($real_name); ?></h5>
                    <span class="text-success small fw-semibold">PTKP: <?= $ptkp_status; ?> (Rp<?= number_format($ptkp_amount, 0, ',', '.'); ?>)</span>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="p-3 rounded-3 bg-dark bg-opacity-50 border border-secondary border-opacity-25">
                    <span class="text-secondary small text-uppercase d-block mb-1">Kurs Acuan Pajak USD ke IDR</span>
                    <h5 class="fw-bold text-success mb-0">Rp<?= number_format($kurs_usd_idr, 2, ',', '.'); ?> / $1 USD</h5>
                    <span class="text-muted small"><i class="bi bi-shield-check me-1"></i> <?= $rate_status_label; ?> (<?= date('d M Y'); ?>)</span>
                </div>
            </div>
        </div>

        
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-dark border border-secondary border-opacity-25 text-center">
                    <span class="text-secondary small text-uppercase d-block mb-1">Total Bruto Bug Bounty</span>
                    <h4 class="fw-bold text-white mb-1">$<?= number_format($total_earnings_usd, 2); ?></h4>
                    <span class="text-success small fw-semibold">Rp<?= number_format($total_bruto_idr, 0, ',', '.'); ?></span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-dark border border-secondary border-opacity-25 text-center">
                    <span class="text-secondary small text-uppercase d-block mb-1">Estimasi PPh 21 Terutang</span>
                    <h4 class="fw-bold text-warning mb-1">$<?= number_format($pph_terutang_usd, 2); ?></h4>
                    <span class="text-warning small fw-semibold">Rp<?= number_format($pph_terutang_idr, 0, ',', '.'); ?></span>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-dark border border-secondary border-opacity-25 text-center">
                    <span class="text-secondary small text-uppercase d-block mb-1">Pendapatan Bersih (Net Payout)</span>
                    <h4 class="fw-bold text-success mb-1">$<?= number_format($net_payout_usd, 2); ?></h4>
                    <span class="text-info small fw-semibold">Rp<?= number_format($total_bruto_idr - $pph_terutang_idr, 0, ',', '.'); ?></span>
                </div>
            </div>
        </div>

        
        <h5 class="fw-bold text-white mb-3"><i class="bi bi-list-check text-success me-2"></i>Rincian Payout Bug Bounty</h5>
        <div class="table-responsive rounded-3 overflow-hidden">
            <table class="table table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID Laporan</th>
                        <th>Judul Kerentanan</th>
                        <th>Jenis Kerentanan</th>
                        <th>Status</th>
                        <th class="text-end">Nominal (USD)</th>
                        <th class="text-end">Nominal Konversi (IDR)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($paid_reports)): ?>
                        <?php foreach ($paid_reports as $rep): ?>
                            <?php 
                                $rep_title = $rep['report_title'] ?? ($rep['title'] ?? 'Laporan #' . $rep['id']);
                                $vuln_type = $rep['vulnerability_type'] ?? 'Web Security Vulnerability';
                                $rep_status = $rep['status'] ?? 'Resolved';
                                $amount_idr = $rep['payout_amount'] * $kurs_usd_idr;
                            ?>
                            <tr>
                                <td class="text-secondary font-monospace">#<?= $rep['id']; ?></td>
                                <td class="fw-semibold text-white"><?= htmlspecialchars($rep_title); ?></td>
                                <td class="text-secondary"><?= htmlspecialchars($vuln_type); ?></td>
                                <td><span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2.5 py-1"><?= htmlspecialchars($rep_status); ?></span></td>
                                <td class="text-end fw-bold text-success">$<?= number_format($rep['payout_amount'], 2); ?></td>
                                <td class="text-end text-info font-monospace">Rp<?= number_format($amount_idr, 0, ',', '.'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">Belum ada catatan payout atau laporan bug berstatus Resolved.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="mt-4 pt-3 border-top border-secondary text-secondary small d-flex justify-content-between align-items-center">
            <span>Dihitung sesuai standar PPh Pasal 21 Pekerja Bebas (NPPN 50% & PTKP <?= $ptkp_status; ?>). Wajib Pajak: <strong><?= htmlspecialchars($real_name); ?></strong>.</span>
            <span>Tanggal Cetak: <?= date('d M Y, H:i'); ?> WIB</span>
        </div>
    </div>
</div>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/native.js"></script>
</body>
</html>