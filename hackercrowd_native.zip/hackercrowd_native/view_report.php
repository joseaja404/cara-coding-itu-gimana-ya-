<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$report_id = $_GET['id'] ?? null;
$user_id   = $_SESSION['user_id'];
$role      = $_SESSION['role'];

if (!$report_id) {
    header("Location: dashboard.php");
    exit;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_comment'])) {
    $comment = trim($_POST['comment']);
    if (!empty($comment)) {
        $stmt_c = $conn->prepare("INSERT INTO report_comments (report_id, user_id, comment) VALUES (?, ?, ?)");
        $stmt_c->bind_param("iis", $report_id, $user_id, $comment);
        $stmt_c->execute();
        log_activity($conn, $user_id, "ADD_COMMENT", "Menambahkan tanggapan pada laporan ID: $report_id");
    }
    header("Location: view_report.php?id=" . $report_id);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status']) && $role == 'company') {
    $new_status = $_POST['status'];
    $reward     = intval($_POST['reward']);

    $stmt = $conn->prepare("UPDATE reports SET status = ?, reward = ? WHERE id = ?");
    $stmt->bind_param("sii", $new_status, $reward, $report_id);
    $stmt->execute();
    log_activity($conn, $user_id, "UPDATE_REPORT", "Company memperbarui status laporan ID: $report_id menjadi $new_status dengan reward $$reward");
    $success = "Status laporan dan reward berhasil diperbarui!";
}


if (isset($_GET['pay_reward']) && $role == 'company') {
    $stmt_pay = $conn->prepare("UPDATE reports SET payment_status = 'Paid' WHERE id = ?");
    $stmt_pay->bind_param("i", $report_id);
    $stmt_pay->execute();
    log_activity($conn, $user_id, "PAY_REWARD", "Company melunasi pembayaran reward untuk laporan ID: $report_id");
    header("Location: view_report.php?id=" . $report_id);
    exit;
}




$stmt = $conn->prepare("SELECT reports.*, programs.title AS program_title, programs.company_id, users.username AS hacker_name 
                        FROM reports 
                        LEFT JOIN programs ON reports.program_id = programs.id 
                        JOIN users ON reports.hacker_id = users.id 
                        WHERE reports.id = ?");
$stmt->bind_param("i", $report_id);
$stmt->execute();
$report = $stmt->get_result()->fetch_assoc();

if (!$report) {
    header("Location: dashboard.php");
    exit;
}

if ($role == 'hacker' && $report['hacker_id'] != $user_id) {
    header("Location: dashboard.php");
    exit;
}

if ($role == 'company' && $report['company_id'] != $user_id) {
    header("Location: dashboard.php");
    exit;
}


$stmt_comments = $conn->prepare("SELECT report_comments.*, users.username, users.role 
                                 FROM report_comments 
                                 JOIN users ON report_comments.user_id = users.id 
                                 WHERE report_id = ? ORDER BY report_comments.id ASC");
$stmt_comments->bind_param("i", $report_id);
$stmt_comments->execute();
$comments = $stmt_comments->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Laporan Bug - HackerCrowd Project</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/native.css">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-slate-900 px-4 py-3 border-bottom border-secondary">
    <a class="navbar-brand fw-bold" href="index.php">
        <i class="bi bi-shield-lock-fill text-success fs-3 me-2"></i> Hacker<span class="text-success">Crowd</span> Project
    </a>
    <div class="ms-auto">
        <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2 rounded-pill px-3"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-3"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
</nav>

<div class="container my-5" style="max-width: 760px;">
    <?php if(isset($success)): ?>
        <div class="alert alert-success d-flex align-items-center mb-4 rounded-4" role="alert">
            <i class="bi bi-check-circle-fill me-2 fs-5"></i>
            <div><?= htmlspecialchars($success) ?></div>
        </div>
    <?php endif; ?>

    <div class="report-card p-4 shadow-lg mb-4">
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <h4 class="fw-bold mb-1 text-white"><?= htmlspecialchars($report['title']) ?></h4>
                <span class="badge bg-danger mt-1"><?= htmlspecialchars($report['severity'] ?? 'Medium') ?> Severity</span>
            </div>
            <div>
                <span class="badge bg-secondary fs-6 px-3 py-2 me-1"><?= htmlspecialchars($report['status']) ?></span>
                <span class="badge <?= $report['payment_status'] == 'Paid' ? 'bg-success' : 'bg-warning text-dark' ?> fs-6 px-3 py-2">
                    Payment: <?= htmlspecialchars($report['payment_status']) ?>
                </span>
            </div>
        </div>
        
        <div class="row g-2 small text-secondary mb-4 border-bottom border-secondary pb-3">
            <div class="col-6"><i class="bi bi-building"></i> Program: <strong class="text-white"><?= htmlspecialchars($report['program_title'] ?? 'Tanpa Program Terkait') ?></strong></div>
            <div class="col-6"><i class="bi bi-person"></i> Researcher: <strong class="text-white"><?= htmlspecialchars($report['hacker_name']) ?></strong></div>
        </div>

        <h6 class="fw-bold mb-2 text-light"><i class="bi bi-journal-text me-1"></i> Detail Kerentanan & Langkah Reproduksi (PoC)</h6>
        <div class="p-3 bg-dark border border-secondary rounded-3 font-monospace small text-light mb-4" style="white-space: pre-line;">
            <?= htmlspecialchars($report['vulnerability_details'] ?? '') ?>
        </div>

        <?php if (!empty($report['attachment'])): ?>
            <div class="pt-3 border-top border-secondary">
                <h6 class="fw-bold mb-2 text-light"><i class="bi bi-paperclip me-1"></i> Lampiran Bukti (Foto / Dokumen):</h6>
                <a href="uploads/<?= htmlspecialchars($report['attachment']) ?>" target="_blank" class="btn btn-sm btn-outline-info">
                    <i class="bi bi-file-earmark-arrow-down"></i> Lihat / Download Lampiran (<?= htmlspecialchars($report['attachment']) ?>)
                </a>
            </div>
        <?php endif; ?>
    </div>

    
    <?php if ($role == 'company'): ?>
    <div class="report-card p-4 shadow-lg mb-4 border-success border-2">
        <h5 class="fw-bold mb-3 text-white"><i class="bi bi-cash-stack text-success me-2"></i>Kirim Pembayaran Reward ke Hacker</h5>
        <p class="text-secondary small">Jika celah sudah diverifikasi dan divalidasi, lakukan pembayaran reward kepada hacker agar tercatat di Hall of Fame publik.</p>
        
        <div class="d-flex justify-content-between align-items-center bg-dark p-3 rounded-3 border border-secondary mb-3">
            <div>
                <small class="text-secondary d-block">Nominal Reward Disetujui</small>
                <span class="text-success fw-bold fs-4">$<?= number_format($report['reward']) ?></span>
            </div>
            <div>
                <?php if ($report['payment_status'] == 'Paid'): ?>
                    <span class="badge bg-success px-4 py-2 fs-6"><i class="bi bi-check-all"></i> Sudah Dibayarkan (Paid)</span>
                <?php else: ?>
                    <a href="view_report.php?id=<?= $report_id ?>&pay_reward=1" class="btn btn-success fw-bold px-4 py-2" onclick="return confirm('Konfirmasi transfer pembayaran reward sebesar $<?= $report['reward'] ?> kepada hacker?')">
                        <i class="bi bi-credit-card-2-front-fill me-1"></i> Bayar Sekarang ($<?= $report['reward'] ?>)
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <hr class="border-secondary my-4">

        <h6 class="fw-bold mb-3 text-white"><i class="bi bi-sliders me-1"></i> Perbarui Status & Nominal Reward</h6>
        <form method="POST">
            <input type="hidden" name="update_status" value="1">
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-light">Status Laporan</label>
                    <select name="status" class="form-select bg-dark text-white border-secondary">
                        <option value="New" <?= $report['status'] == 'New' ? 'selected' : '' ?>>New</option>
                        <option value="Triaged" <?= $report['status'] == 'Triaged' ? 'selected' : '' ?>>Triaged</option>
                        <option value="Resolved" <?= $report['status'] == 'Resolved' ? 'selected' : '' ?>>Resolved</option>
                        <option value="Closed" <?= $report['status'] == 'Closed' ? 'selected' : '' ?>>Closed</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-light">Nominal Reward ($)</label>
                    <div class="input-group">
                        <span class="input-group-text bg-dark border-secondary text-success fw-bold">$</span>
                        <input type="number" name="reward" class="form-control bg-dark text-white border-secondary" value="<?= $report['reward'] ?>" min="0" required>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-outline-light w-100 fw-bold py-2">
                <i class="bi bi-save me-1"></i> Perbarui Status & Reward
            </button>
        </form>
    </div>
    <?php endif; ?>

    
    <div class="report-card p-4 shadow-lg mb-4">
        <h5 class="fw-bold mb-4 text-white"><i class="bi bi-chat-dots me-2"></i>Aktivitas & Diskusi Laporan</h5>
        
        <div class="mb-4">
            <?php if($comments->num_rows > 0): ?>
                <?php while($c = $comments->fetch_assoc()): ?>
                    <div class="d-flex mb-3">
                        <img src="https://api.dicebear.com/7.x/identicon/svg?seed=<?= urlencode($c['username']) ?>" class="rounded-circle me-3 bg-light" style="width: 38px; height: 38px;" alt="Avatar">
                        <div class="comment-box p-3 w-100">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <strong class="text-white"><?= htmlspecialchars($c['username']) ?> <span class="badge bg-secondary ms-1"><?= ucfirst($c['role']) ?></span></strong>
                                <small class="text-secondary"><?= date("d M H:i", strtotime($c['created_at'])) ?></small>
                            </div>
                            <p class="mb-0 small text-light opacity-75" style="white-space: pre-line;"><?= htmlspecialchars($c['comment']) ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-secondary text-center small py-3">Belum ada diskusi atau tanggapan pada laporan ini.</p>
            <?php endif; ?>
        </div>

        <form method="POST">
            <input type="hidden" name="add_comment" value="1">
            <div class="mb-3">
                <textarea name="comment" class="form-control bg-dark text-white border-secondary" rows="3" placeholder="Tulis tanggapan, pertanyaan klarifikasi, atau informasi tambahan..." required></textarea>
            </div>
            <div class="d-flex justify-content-between align-items-center">
                <a href="dashboard.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Kembali</a>
                <button type="submit" class="btn btn-success fw-bold px-4">
                    <i class="bi bi-send me-1"></i> Kirim Tanggapan
                </button>
            </div>
        </form>
    </div>
</div>

<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/native.js"></script>
</body>
</html>